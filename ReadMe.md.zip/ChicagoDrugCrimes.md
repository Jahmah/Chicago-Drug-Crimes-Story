

```python
%matplotlib inline
```


```python
# Dependencies
import pandas as pd
import numpy as np
import calendar
import matplotlib.pyplot as plt
from datetime import datetime
import gmaps
```


```python
# Google developer API key
from config import gkey

# Access maps with unique API key
gmaps.configure(api_key=gkey)
```


```python
# Specify the path to the CSV file
file = 'C:\\Users\\Nii\\MyTraining\\Resources\\Chicago_Crimes-2001_to_2018.csv'
```


```python
# Read the CSV in pandas. 
# Ensure the correct encoding is used to read file
df = pd.read_csv(file, encoding="ISO-8859-1")
```

####  DATA CLEANING:


```python
# Preview the DataFrame
#df.head(2)
```


```python
# List all column names in DataFrame
#df.columns
```


```python
# Delete unecessary columns in DataFrame
crimes_df = df.drop(['Case Number', 'IUCR', 'Arrest','Domestic','Beat',
                     'Community Area','FBI Code', 'X Coordinate', 'Y Coordinate', 
                     'Updated On','Location', 'District'], axis = 1)

#crimes_df.head()
```


```python
#crimes_df.columns
```


```python
# Identify incomplete rows
#crimes_df.count()
```


```python
# Drop all rows with missing information
crimes_df = crimes_df.dropna(how='any')
```


```python
# Verify dropped rows
#crimes_df.count()
```


```python
# Reorganize Columns
crimes_df = crimes_df[['ID','Date','Year','Primary Type','Description', 'Location Description',
                       'Block','Ward','Latitude','Longitude']]

crimes_df.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Date</th>
      <th>Year</th>
      <th>Primary Type</th>
      <th>Description</th>
      <th>Location Description</th>
      <th>Block</th>
      <th>Ward</th>
      <th>Latitude</th>
      <th>Longitude</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10000092</td>
      <td>03/18/2015 07:44:00 PM</td>
      <td>2015</td>
      <td>BATTERY</td>
      <td>AGGRAVATED: HANDGUN</td>
      <td>STREET</td>
      <td>047XX W OHIO ST</td>
      <td>28.0</td>
      <td>41.891399</td>
      <td>-87.744385</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10000094</td>
      <td>03/18/2015 11:00:00 PM</td>
      <td>2015</td>
      <td>OTHER OFFENSE</td>
      <td>PAROLE VIOLATION</td>
      <td>STREET</td>
      <td>066XX S MARSHFIELD AVE</td>
      <td>15.0</td>
      <td>41.773372</td>
      <td>-87.665319</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10000095</td>
      <td>03/18/2015 10:45:00 PM</td>
      <td>2015</td>
      <td>BATTERY</td>
      <td>DOMESTIC BATTERY SIMPLE</td>
      <td>APARTMENT</td>
      <td>044XX S LAKE PARK AVE</td>
      <td>4.0</td>
      <td>41.813861</td>
      <td>-87.596643</td>
    </tr>
  </tbody>
</table>
</div>




```python
#crimes_df.dtypes
```


```python
#crimes_df['Primary Type'].value_counts()
```


```python
# Combine similar offenses together
crimes_df["Primary Type"] = crimes_df["Primary Type"].replace({
     "THEFT": "THEFT & ROBBERY", "BURGLARY": "THEFT & ROBBERY", "MOTOR VEHICLE THEFT": "THEFT & ROBBERY",
     "ROBBERY": "THEFT & ROBBERY", "BATTERY": "ASSAULT", "CRIM SEXUAL ASSAULT": "ASSAULT", "PROSTITUTION": "SEX CRIMES",
     "SEX OFFENSE": "SEX CRIMES", "CRIMINAL TRESPASS": "CRIMINAL DAMAGE", "ARSON": "CRIMINAL DAMAGE", "OTHER OFFENSE":
     "OTHER OFFENSES", "DECEPTIVE PRACTICE": "OTHER OFFENSES", "WEAPONS VIOLATION": "OTHER OFFENSES", "GAMBLING":
     "OTHER OFFENSES", "STALKING": "OTHER OFFENSES", "KIDNAPPING": "OTHER OFFENSES", "OBSCENITY": "OTHER OFFENSES",
     "INTIMIDATION": "OTHER OFFENSES", "RITUALISM": "OTHER OFFENSES", "HUMAN TRAFFICKING": "OTHER OFFENSES",
     "CONCEALED CARRY LICENSE VIOLATION": "OTHER OFFENSES", "NON-CRIMINAL (SUBJECT SPECIFIED)": "OTHER OFFENSES",
     "NON-CRIMINAL": "OTHER OFFENSES", "PUBLIC PEACE VIOLATION": "OTHER OFFENSES", "OFFENSE INVOLVING CHILDREN":
     "OTHER OFFENSES", "INTERFERENCE WITH PUBLIC OFFICER": "OTHER OFFENSES", "LIQUOR LAW VIOLATION": "OTHER OFFENSES",
     "NON - CRIMINAL": "OTHER OFFENSES", "OTHER NARCOTIC VIOLATION": "NARCOTICS", "PUBLIC INDECENCY": "OTHER OFFENSES",
     "HOMICIDE": "ASSAULT" })

crimes_df['Primary Type'].value_counts()
```




    THEFT & ROBBERY    2108807
    ASSAULT            1492914
    CRIMINAL DAMAGE     869013
    OTHER OFFENSES      795859
    NARCOTICS           630713
    SEX CRIMES           80550
    Name: Primary Type, dtype: int64




```python
crimes_df['Location Description'] = crimes_df['Location Description'].replace({"SIDEWALK":"STREET", "ALLEY":"STREET",
            "APARTMENT":"RESIDENCE","RESIDENCE-GARAGE":"RESIDENCE","RESIDENCE PORCH/HALLWAY": 
            "RESIDENCE", "RESIDENTIAL YARD (FRONT/BACK)":"RESIDENCE","CHA APARTMENT": "RESIDENCE",
            "CHA HALLWAY/STAIRWELL/ELEVATOR": "RESIDENCE","SMALL RETAIL STORE":"RETAIL OUTLET","DRUG STORE":
            "RETAIL OUTLET","GAS STATION":"RETAIL OUTLET","DEPARTMENT STORE":"RETAIL OUTLET","RETAIL STORES":
            "RETAIL OUTLET","RESTAURANT":"BUSINESS","BAR OR TAVERN":"BUSINESS","RESTAURANT":"BUSINESS","BANK":
            "BUSINESS","HOTEL/MOTEL":"BUSINESS","VEHICLE NON-COMMERCIAL":"VEHICLE","PARKING LOT":"PUBLIC BUILDING/GROUNDS",
            "SCHOOL, PUBLIC, BUILDING":"SCHOOL","PARK PROPERTY":"PUBLIC BUILDING/GROUNDS","CTA PLATFORM":
            "PUBLIC BUILDING/GROUNDS","CHA PARKING LOT/GROUNDS":"PUBLIC BUILDING/GROUNDS","SCHOOL, PUBLIC, GROUNDS":
            "SCHOOL", "CTA TRAIN":"PUBLIC BUILDING/GROUNDS","VACANT LOT/LAND":"PUBLIC BUILDING/GROUNDS",
            "GROCERY FOOD STORE":"RETAIL OUTLET","PUBLIC HIGH SCHOOL":"SCHOOL",'CTA "L" TRAIN':
            "PUBLIC BUILDING/GROUNDS","PARKING LOT/GARAGE(NON.RESID.)":"PUBLIC BUILDING/GROUNDS","CTA BUS":"VEHICLE",
            "TAVERN/LIQUOR STORE":"RETAIL OUTLET","HOSPITAL BUILDING/GROUNDS":"HOSPITAL",
            "POLICE FACILITY/VEH PARKING LOT":"POLICE BUILDING","CONVENIENCE STORE":
            "RETAIL OUTLET","CHURCH/SYNAGOGUE/PLACE OF WORSHIP":"CHURCH","GOVERNMENT BUILDING/PROPERTY":
            "FEDERAL BUILDING","SCHOOL, PRIVATE, BUILDING":"SCHOOL","GOVERNMENT BUILDING":
            "FEDERAL BUILDING","CONSTRUCTION SITE":"BUSINESS","WAREHOUSE":"BUSINESS","AIRCRAFT":"AIRPORT",
            "ABANDONED BUILDING":"OTHER","CTA GARAGE / OTHER PROPERTY":"PUBLIC BUILDING/GROUNDS","TAXICAB":"VEHICLE",
            "CTA BUS STOP":"PUBLIC BUILDING/GROUNDS","BARBERSHOP":"BUSINESS","CURRENCY EXCHANGE":"BUSINESS","LIBRARY":
            "PUBLIC BUILDING/GROUNDS","ATHLETIC CLUB":"PUBLIC BUILDING/GROUNDS","MEDICAL/DENTAL OFFICE":"BUSINESS",
            "FACTORY/MANUFACTURING BUILDING":"BUSINESS","COMMERCIAL / BUSINESS OFFICE":"BUSINESS","SCHOOL, PRIVATE, GROUNDS":
            "SCHOOL","CLEANING STORE":"RETAIL OUTLET","VEHICLE-COMMERCIAL":"VEHICLE","COLLEGE/UNIVERSITY GROUNDS":"SCHOOL",
            "DRIVEWAY - RESIDENTIAL":"RESIDENCE","SPORTS ARENA/STADIUM":"PUBLIC BUILDING/GROUNDS","CTA STATION":
            "PUBLIC BUILDING/GROUNDS","ATM (AUTOMATIC TELLER MACHINE)":"BUSINESS","DAY CARE CENTER":"SCHOOL","BUSINESS":
            "BUSINESS","CAR WASH":"BUSINESS","AUTO":"VEHICLE","COLLEGE/UNIVERSITY RESIDENCE HALL":"SCHOOL","MOVIE HOUSE/THEATER":
            "RETAIL OUTLET", "APPLIANCE STORE":"RETAIL OUTLET","HIGHWAY/EXPRESSWAY":"STREET","LAKEFRONT/WATERFRONT/RIVERBANK":
            "OTHER","AIRPORT TERMINAL UPPER LEVEL - SECURE AREA":"AIRPORT","AIRPORT TERMINAL LOWER LEVEL - NON-SECURE AREA":
            "AIRPORT","AIRPORT BUILDING NON-TERMINAL - NON-SECURE AREA":"AIRPORT","AIRPORT VENDING ESTABLISHMENT":"AIRPORT",
            "AIRPORT TERMINAL LOWER LEVEL - SECURE AREA":"AIRPORT","AIRPORT BUILDING NON-TERMINAL - SECURE AREA":"AIRPORT",
            "DELIVERY TRUCK":"VEHICLE","ANIMAL HOSPITAL":"HOSPITAL","AIRPORT TERMINAL UPPER LEVEL - NON-SECURE AREA":"AIRPORT",
            "AIRPORT PARKING LOT":"AIRPORT","OTHER COMMERCIAL TRANSPORTATION":"VEHICLE","VEHICLE - OTHER RIDE SERVICE":"VEHICLE",
            "CREDIT UNION":"BUSINESS","AIRPORT EXTERIOR - NON-SECURE AREA":"AIRPORT","HOUSE":"RESIDENCE","AIRPORT EXTERIOR - SECURE AREA":
            "AIRPORT", "POOL ROOM":"OTHER","COIN OPERATED MACHINE":"OTHER","PAWN SHOP":"OTHER","YARD":"OTHER","BOWLING ALLEY":"OTHER",
            "BOAT/WATERCRAFT":"OTHER","BRIDGE":"STREET","CEMETERY":"PUBLIC BUILDING/GROUNDS","FOREST PRESERVE":
            "OTHER","SAVINGS AND LOAN":"BUSINESS","VACANT LOT":"OTHER","GANGWAY":"AIRPORT","PUBLIC BUILDING/GROUND":"PUBLIC BUILDING/GROUNDS",
            "VEHICLE - OTHER RIDE SHARE SERVICE (E.G., UBER, LYFT)":"VEHICLE","PORCH":"RESIDENCE","NEWSSTAND":"STREET","RETAIL STORE":"RETAIL OUTLET",
            "AIRPORT TERMINAL MEZZANINE - NON-SECURE AREA":"AIRPORT","AIRPORT TRANSPORTATION SYSTEM (ATS)":"AIRPORT","HALLWAY":"OTHER",
            "VEHICLE - DELIVERY TRUCK":"VEHICLE","AUTO / BOAT / RV DEALERSHIP":"BUSINESS","CEMETARY":"PUBLIC BUILDING/GROUNDS","GARAGE":"OTHER",
            "CTA TRACKS - RIGHT OF WAY":"OTHER","CHA PARKING LOT":"PUBLIC BUILDING/GROUNDS","GAS STATION DRIVE/PROP.":"RETAIL OUTLET",
            "CHA GROUNDS":"PUBLIC BUILDING/GROUNDS","TAVERN":"BUSINESS","BASEMENT":"RESIDENCE","CHA HALLWAY":"RESIDENCE","OFFICE":"BUSINESS",
            "DRIVEWAY":"RESIDENCE","VESTIBULE":"OTHER","STAIRWELL":"OTHER","HOTEL":"BUSINESS","CLUB":"BUSINESS","OFFICE":"BUSINESS","BARBER SHOP/BEAUTY SALON":
            "BUSINESS","SCHOOL YARD":"SCHOOL","RAILROAD PROPERTY":"PUBLIC BUILDING/GROUNDS","PUBLIC GRAMMAR SCHOOL":"SCHOOL","TRUCK":"VEHICLE","TAXI CAB":
            "VEHICLE","DUMPSTER":"VEHICLE","MOTEL":"BUSINESS","CHA LOBBY":"PUBLIC BUILDING/GROUNDS","CHA STAIRWELL":"PUBLIC BUILDING/GROUNDS",
            "GARAGE/AUTO REPAIR":"BUSINESS","LIQUOR STORE":"RETAIL OUTLET","NURSING HOME":"HOSPITAL","CTA PROPERTY":"PUBLIC BUILDING/GROUNDS","TRAILER":"OTHER",
            "YMCA":"OTHER","LAKE":"OTHER","VEHICLE-COMMERCIAL - TROLLEY BUS":"VEHICLE","VEHICLE-COMMERCIAL - ENTERTAINMENT/PARTY BUS":"VEHICLE","RIVER":"OTHER",
            "KENNEL":"OTHER","FUNERAL PARLOR":"BUSINESS","BANQUET HALL":"OTHER","ROOMING HOUSE":"OTHER","LIVERY STAND OFFICE":"BUSINESS",
            "LAUNDRY ROOM":"OTHER","PRAIRIE":"OTHER","RIVER BANK":"OTHER","COACH HOUSE":"OTHER","SEWER":"OTHER","LAGOON":"OTHER","CLEANERS/LAUNDROMAT":"BUSINESS",
            "HORSE STABLE":"OTHER","FACTORY":"BUSINESS","CHA BREEZEWAY":"OTHER","CHA ELEVATOR":"PUBLIC BUILDING/GROUNDS","FARM":"OTHER","ELEVATOR":"OTHER",
            "POOLROOM":"OTHER","WOODED AREA":"OTHER","LOADING DOCK":"OTHER","TRUCKING TERMINAL":"OTHER","LIVERY AUTO":"BUSINESS","CHURCH PROPERTY":"CHURCH",
            "EXPRESSWAY EMBANKMENT":"STREET","CHA PLAY LOT":"PUBLIC BUILDING/GROUNDS",'CTA "L" PLATFORM':"PUBLIC BUILDING/GROUNDS","JUNK YARD/GARBAGE DUMP":
            "OTHER","COUNTY JAIL":"POLICE/FIRE STATION","JAIL / LOCK-UP FACILITY":"POLICE/FIRE STATION","POLICE BUILDING":"POLICE/FIRE STATION",
            "NURSING HOME/RETIREMENT HOME":"HOSPITAL", "FIRE STATION":"POLICE/FIRE STATION","OTHER RAILROAD PROP / TRAIN DEPOT":"PUBLIC BUILDING/GROUNDS","AIPORT/AIRCRAFT":
            "AIRPORT/AIRCRAFT","AIRPORT": "AIRPORT/AIRCRAFT","HOSPITAL":"PUBLIC BUILDING/GROUNDS","CHURCH":"OTHER","FEDERAL BUILDING":"PUBLIC BUILDING/GROUNDS",
            "POLICE/FIRE STATION":"PUBLIC BUILDING/GROUNDS","AIRPORT/AIRCRAFT":"PUBLIC BUILDING/GROUNDS","PUBLIC BUILDING/GROUNDS":"PUBLIC BLDG"                                        
            })
```


```python
# Filter the data so that only those listd as 'Narcotics' are in a DataFrame
drugs_crime_df = crimes_df.loc[crimes_df["Primary Type"] == "NARCOTICS", :]

drugs_crime_df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Date</th>
      <th>Year</th>
      <th>Primary Type</th>
      <th>Description</th>
      <th>Location Description</th>
      <th>Block</th>
      <th>Ward</th>
      <th>Latitude</th>
      <th>Longitude</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>8</th>
      <td>10000101</td>
      <td>03/18/2015 10:09:00 PM</td>
      <td>2015</td>
      <td>NARCOTICS</td>
      <td>POSS: CANNABIS 30GMS OR LESS</td>
      <td>STREET</td>
      <td>036XX S WOLCOTT AVE</td>
      <td>11.0</td>
      <td>41.828138</td>
      <td>-87.672782</td>
    </tr>
    <tr>
      <th>36</th>
      <td>10000139</td>
      <td>03/19/2015 01:15:00 AM</td>
      <td>2015</td>
      <td>NARCOTICS</td>
      <td>POSS: CANNABIS 30GMS OR LESS</td>
      <td>STREET</td>
      <td>035XX W CERMAK RD</td>
      <td>22.0</td>
      <td>41.851682</td>
      <td>-87.713304</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Convert the Date column to a datetime type 
drugs_crime_df['Date'] = pd.to_datetime(drugs_crime_df['Date'])
```


```python
# Separate the time element of the Date column into a new column 
drugs_crime_df['Time'] = drugs_crime_df['Date'].dt.time
```


```python
# Separate the Month element of the Date column into a new column 
drugs_crime_df['Month'] = drugs_crime_df['Date'].dt.month

# Use list comprehension and apply function to convert month as integer to a string object
drugs_crime_df['Month'] = drugs_crime_df['Month'].apply(lambda x: calendar.month_abbr[x])

```


```python
# Combine similar offenses together
drugs_crime_df['Description'] = drugs_crime_df["Description"].replace({"POSS: CANNABIS 30GMS OR LESS":"CANNABIS",
                                "POSS CRACK":'COCAINE',"POSS: HEROIN(WHITE)":"HEROIN","POSS: COCAINE":"COCAINE",
                               "MANU/DELIVER: HEROIN (WHITE)":"HEROIN","POSS: CANNABIS MORE THAN 30GMS":"CANNABIS",
                                "MANU/DEL:CANNABIS OVER 10 GMS":"CANNABIS","ATTEMPT POSSESSION CANNABIS":"CANNABIS",
                                "CANNABIS PLANT":"CANNABIS","POSSESSION: SYNTHETIC MARIJUANA":"CANNABIS",
                                "DELIVER CANNABIS TO PERSON <18":"CANNABIS","MANU/POSS. W/INTENT TO DELIVER: SYNTHETIC MARIJUANA":
                                "CANNABIS","MANU/DEL:CANNABIS 10GM OR LESS":"CANNABIS","POSS: CRACK":"COCAINE","POSS: PCP":"OTHERS",
                                "POSS: SYNTHETIC DRUGS":"OTHERS","POSS: HEROIN(BRN/TAN)":"OTHERS","MANU/DELIVER:CRACK":"COCAINE",
                                "POSS: HALLUCINOGENS":"OTHERS","MANU/DELIVER:COCAINE":"COCAINE","CALCULATED CANNABIS CONSPIRACY":
                                "CANNABIS","ALTER/FORGE PRESCRIPTION":"OTHERS","POSS: BARBITUATES":"OTHERS","POS: HYPODERMIC NEEDLE":
                                "HEROIN","POSS: AMPHETAMINES": "OTHERS","SALE/DEL HYPODERMIC NEEDLE": "HEROIN","SOLICIT NARCOTICS ON PUBLICWAY":
                                "CANNABIS","ATTEMPT POSSESSION NARCOTICS": "CANNABIS", "ATTEMPT POSSESSION NARCOTICS": "CANNABIS",
                                "INTOXICATING COMPOUNDS":"OTHERS", "CRIMINAL DRUG CONSPIRACY": "OTHERS", "FOUND SUSPECT NARCOTICS": "CANNABIS",
                                "POSSESSION OF DRUG EQUIPMENT": "OTHERS","FORFEIT PROPERTY": "OTHERS", "POSSESSION OF DRUG EQUIPMENT": "OTHERS",
                                "MANU/DELIVER: HEROIN(BRN/TAN)": "HEROIN", "MANU/DELIVER: HALLUCINOGEN": "OTHERS", "POSS: METHAMPHETAMINES": "OTHERS",
                                "MANU/DELIVER:PCP": "OTHERS", "POSS: HEROIN(BLACK TAR": "HEROIN", "MANU/DELIVER:BARBITUATES": "OTHERS",
                                "MANU/DELIVER:SYNTHETIC DRUGS": "OTHERS","SALE/DEL DRUG PARAPHERNALIA":"OTHERS","CONT SUBS:FAIL TO MAINT RECORD":
                                "OTHERS","FAIL REGISTER LIC:CONT SUBS":"OTHERS","FAILURE TO KEEP HYPO RECORDS":"OTHERS","POSS: HEROIN(BLACK TAR)": 
                                "HEROIN", "POSS: LOOK-ALIKE DRUGS":"OTHERS","MANU/DELIVER:AMPHETAMINES": "OTHERS","MANU/DELIVER: METHAMPHETAMINES":
                                "OTHERS", "DEL CONT SUBS TO PERSON <18":"OTHERS", "MANU/DELIVER:HEROIN(BLACK TAR)":"HEROIN",
                                "MANU/DELIVER:LOOK-ALIKE DRUG":"OTHERS"
                                 })
                                                                              
```


```python
drugs_crime_df['Description'].value_counts()
```




    CANNABIS    352641
    COCAINE     143615
    HEROIN      103818
    OTHERS       30639
    Name: Description, dtype: int64




```python
# Reorganize Columns
drugs_crime_df = drugs_crime_df[['ID','Date','Year','Month','Time','Primary Type','Description', 'Location Description',
                                 'Block','Ward','Latitude','Longitude']]

drugs_crime_df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Date</th>
      <th>Year</th>
      <th>Month</th>
      <th>Time</th>
      <th>Primary Type</th>
      <th>Description</th>
      <th>Location Description</th>
      <th>Block</th>
      <th>Ward</th>
      <th>Latitude</th>
      <th>Longitude</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>8</th>
      <td>10000101</td>
      <td>2015-03-18 22:09:00</td>
      <td>2015</td>
      <td>Mar</td>
      <td>22:09:00</td>
      <td>NARCOTICS</td>
      <td>CANNABIS</td>
      <td>STREET</td>
      <td>036XX S WOLCOTT AVE</td>
      <td>11.0</td>
      <td>41.828138</td>
      <td>-87.672782</td>
    </tr>
    <tr>
      <th>36</th>
      <td>10000139</td>
      <td>2015-03-19 01:15:00</td>
      <td>2015</td>
      <td>Mar</td>
      <td>01:15:00</td>
      <td>NARCOTICS</td>
      <td>CANNABIS</td>
      <td>STREET</td>
      <td>035XX W CERMAK RD</td>
      <td>22.0</td>
      <td>41.851682</td>
      <td>-87.713304</td>
    </tr>
  </tbody>
</table>
</div>



#### CRIMES IN PERCENTAGES:


```python
# Labels for the sections of our pie chart
labels = ['Theft & Robbery','Assault','Criminal Damage','Other Offenses','Narcotics',"Sex Crimes"]

# The colors of each section of the pie chart
colors = ["yellow", "lightgray", "lightcoral", "lightskyblue", "red", "blue"]

# Tells matplotlib to seperate the "Narcotics" section from the others
explode = (0, 0, 0, 0, 0.2, 0)

# Set figure size
plt.figure(figsize=(10,6))

# Creates the pie chart based upon the values above
plt.pie(crimes_df['Primary Type'].value_counts(), explode=explode, labels=labels, colors=colors,
        autopct="%1.0f%%", shadow=True, startangle= 180)

# Incorporate other chart properties
plt.axis("equal")
plt.title("Crimes in Chicago(%) - 2001 to 2018")

# Save the output
plt.savefig("Chicago_crimes_Images\\Crimes_in_chicago.png")

plt.show()
```


![png](output_26_0.png)



```python
# Labels for the sections of our pie chart
labels = ['Cannabis','Cocaine','Heroin','Others']

# The colors of each section of the pie chart
colors = ["lightgreen", "pink", "yellow", "blue"]

# Tells matplotlib to seperate the "Narcotics" section from the others
explode = (0.1, 0, 0, 0, )

# Set figure size
plt.figure(figsize=(10,6))

# Creates the pie chart based upon the values above
plt.pie(drugs_crime_df['Description'].value_counts(), explode=explode, labels=labels, colors=colors,
        autopct="%1.0f%%", shadow=True, startangle= 180)

# Incorporate other chart properties
plt.axis("equal")
plt.title("Drug Crimes in Chicago(%) - 2001 to 2018")

# Save the output
plt.savefig("Chicago_crimes_Images\\Drug_crimes_chicago.png")

plt.show()
```


![png](output_27_0.png)





#### DRUG CRIMES BY YEAR:



```python
# Creating a new DataFrame using both Year and Primary Type
drugs_crime_year = pd.DataFrame({"No. of Drug Crimes":drugs_crime_df.groupby(['Year'])['Primary Type'].count()})

# Reset index and sort values by Year
drugs_crime_year = drugs_crime_year.reset_index()
drugs_crime_year = drugs_crime_year.sort_values('Year', ascending=True)
                                         
drugs_crime_year.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>No. of Drug Crimes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2001</td>
      <td>120</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2002</td>
      <td>33980</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Set figure size
plt.figure(figsize=(10,6))

# Plot the number of drug crimes per year
plt.plot(drugs_crime_year['Year'], drugs_crime_year['No. of Drug Crimes'], marker ='o', color='blue', label="Drug Crimes")

# Incorporate other graph properties
plt.title('Chicago Drug Crimes - 2001 to 2018')
plt.xlabel("Year")
plt.ylim(0,60000)
plt.ylabel("No. of Drug Crimes")
plt.legend(loc='best')
plt.xticks(np.arange(2001,2019,1), rotation = 65)
plt.grid(True)

# Save the output
plt.savefig("Chicago_crimes_Images\\Chicago_drug_crimes.png")

plt.show()
         
```


![png](output_30_0.png)


#### CRIMES AND LOCATIONS:


```python
#crimes_df['Location Description'].value_counts()
all_crime_locations = pd.DataFrame({"No. of Drug Crimes":crimes_df['Location Description'].value_counts()})

all_crime_locations.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>No. of Drug Crimes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>STREET</th>
      <td>2299708</td>
    </tr>
    <tr>
      <th>RESIDENCE</th>
      <td>1990768</td>
    </tr>
    <tr>
      <th>PUBLIC BLDG</th>
      <td>462197</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Assign Variables for plotting  
y_axis = all_crime_locations['No. of Drug Crimes']
x_axis = all_crime_locations.index
color = ['red','blue','cyan','green', 'yellow',]

# Set figure size
plt.figure(figsize=(10,6))

# Create a Bar plot  
plt.bar(x_axis, y_axis , color=color, alpha=0.7, align="center")

# Incorporate other chart properties
plt.title(" Locations of Crimes in Chicago")
plt.ylabel("No. of Drug Crimes")
plt.xticks(rotation=72)
plt.grid(True)

# Save the output
plt.savefig("Chicago_crimes_Images\\Crimes_locations_chicago.png")

plt.show()
```


![png](output_33_0.png)



```python
# Create a dataframe by grouping Location Description and counting Primary Type
drugs_crime_locations = pd.DataFrame({"Crime_count": drugs_crime_df.groupby(['Location Description'])['Primary Type'].count() })

# Reset index and sort values by crime count
drugs_crime_locations = drugs_crime_locations.reset_index()
drugs_crime_locations = drugs_crime_locations.sort_values('Crime_count', ascending=False)

drugs_crime_locations.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Location Description</th>
      <th>Crime_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6</th>
      <td>STREET</td>
      <td>464676</td>
    </tr>
    <tr>
      <th>3</th>
      <td>RESIDENCE</td>
      <td>55596</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Assign Variables for plotting  
x_axis = drugs_crime_locations['Location Description']
y_axis = drugs_crime_locations['Crime_count']
color = ['red','blue','cyan','green', 'yellow', 'purple', 'navy']

# Set figure size
plt.figure(figsize=(10,6))

# Create a Bar plot  
plt.bar(x_axis, y_axis , color=color, alpha=0.7, align="center")

# Incorporate other chart properties
plt.title("Locations of Drug Crimes")
plt.ylabel("No. of Drug Crimes")
plt.xlabel("Crime Location")
plt.xticks(rotation=72)
plt.grid(True)

# Save the output
plt.savefig("Chicago_crimes_Images\\DrugCrimes_locations_chicago.png")

plt.show()
```


![png](output_35_0.png)



#### DRUG CRIMES BY MONTH AND TIME :



```python
# Creating a new DataFrame using Month and Primary Type columns
drugs_crime_month = pd.DataFrame({"No. of Drug Crimes":drugs_crime_df.groupby(['Month'])['Primary Type'].count() })

# Reset index and sort values by number of drug crimes
drugs_crime_month = drugs_crime_month.reset_index()
drugs_crime_month = drugs_crime_month.sort_values('No. of Drug Crimes', ascending=False)

drugs_crime_month.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Month</th>
      <th>No. of Drug Crimes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>8</th>
      <td>May</td>
      <td>55598</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Mar</td>
      <td>55545</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Aug</td>
      <td>55265</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Set figure size
plt.figure(figsize=(10,6))

# Create a Bar plot  
plt.bar(drugs_crime_month['Month'], drugs_crime_month['No. of Drug Crimes'] , color='lightskyblue', alpha=0.8, align="center")

# Incorporate other chart properties
plt.title("Drug Crimes per month")
plt.ylabel("No. of Drug Crimes")
plt.ylim(10000,60000)
plt.xlabel("Month")
plt.xticks(rotation=45)
plt.grid(True)

# Save the output
plt.savefig("Chicago_crimes_Images\\DrugCrimes_months_chicago.png")

plt.show()
```


![png](output_38_0.png)



```python
# Create a Dataframe for number of drug crimes and time of crimes
times = drugs_crime_df['Time'].value_counts()
drugs_crime_times = pd.DataFrame({"No. of Crimes":drugs_crime_df['Time'].value_counts(), "Time":times.index})

# Change the Time column to a datetime type and format as Hour
drugs_crime_times["Time"] = pd.to_datetime(drugs_crime_times["Time"], format='%X').dt.hour

# Reset Dataframe index
drugs_crime_times = drugs_crime_times.reset_index()
  
# Group dataframe by Time and count of Time
drugs_crime_timess = drugs_crime_times.groupby('Time')['Time'].count()
drugs_crime_timess = pd.DataFrame({"No. of Crimes":drugs_crime_timess})

drugs_crime_timess.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>No. of Crimes</th>
    </tr>
    <tr>
      <th>Time</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2792</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2354</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1856</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Assign Variables for Bar plot  
x_axis = ['12am','1am','2am','3am','4am','5am','6am','7am','8am','9am','10am','11am','12pm',
          '1pm','2pm','3pm','4pm','5pm','6pm','7pm','8pm','9pm','10pm','11pm']

y_axis = drugs_crime_timess['No. of Crimes']

color = ['lightskyblue','cyan']

# Set figure size
plt.figure(figsize=(10,6))

# Create a Bar plot  
plt.bar(x_axis, y_axis , color=color, alpha=0.8, align="center")

# Incorporate other chart properties
plt.title("Drug Crimes per Time of day")
plt.ylabel("No. of Drug Crimes")
plt.xlabel("Time")
plt.xticks(rotation=85)
plt.grid(True)

# Save the output
plt.savefig("Chicago_crimes_Images\\DrugCrimes_times_chicago.png")

plt.show()
```


![png](output_40_0.png)


#### HEATMAP OF DRUG CRIME LOCATIONS


```python
# Set up a variable for longitude and latitude coordinates                                                 
coordinates = drugs_crime_df[['Latitude', 'Longitude']]

# Customize the size of the figure
figure_layout = {
    'width': '400px',
    'height': '300px',
    'border': '1px solid black',
    'padding': '1px',
    'margin': '0 auto 0 auto'
}

# Assign layout to a variable
fig = gmaps.figure(figure_layout)

# Assign the marker layer to a variable
markers = gmaps.heatmap_layer(coordinates)

# Add the layer to the map
fig.add_layer(markers)

fig
```


    Figure(layout=FigureLayout(height='420px'))

